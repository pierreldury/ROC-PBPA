from flask import Flask, request, jsonify
import requests
import json
import time

app = Flask(__name__)

# ----- AWS API Gateway Configuration -----
API_GATEWAY_URL = "https://973ojwgu29.execute-api.us-east-1.amazonaws.com/PROD/"  # Replace with your API Gateway URL

# ----- Flask Route to Receive Sensor Data -----
@app.route('/sensor-data', methods=['POST'])
def sensor_data():
    print(request)
    try:
        # Parse the JSON payload sent by the Arduino
        data = request.get_json()
        print("Received sensor data:", data)

        # Optionally, add a timestamp
        data['timestamp'] = str(int(time.time()))

        # Convert the data to a JSON string for HTTP request
        payload = json.dumps(data)
        print(f"Payload type: ", payload)

        # Send the payload to AWS API Gateway via HTTP POST
        response = requests.post(API_GATEWAY_URL, data=payload, headers={'Content-Type': 'application/json'})

        if response.status_code == 200:
            print("Published to AWS API Gateway:", payload)
            return jsonify({"status": "success"}), 200
        else:
            print("Failed to publish to AWS API Gateway:", response.text)
            return jsonify({"status": "error", "message": response.text}), response.status_code
    except Exception as e:
        print("Error processing sensor data:", e)
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    # Run the Flask server on port 5000; accessible to devices on your local network
    app.run(host='0.0.0.0', port=5000, debug=True)
